import math
lines = open("spawnnewcube.mcfunction").read().split("\n")

def is_extreme(x):
    return abs(x) > 0.499

def is_edge(coords):
    extreme_count = 0
    for dim in coords:
        if is_extreme(dim):
            extreme_count += 1
    if(extreme_count > 1):
        return True
    return False

def point_normal(coords):
    ret = [0, 0, 0]
    for i, x in enumerate(coords):
        if(is_extreme(x)):
            ret[i] = math.copysign(1, x)
            return ret
lines_out = []
for line in lines:
    if(line[:6] == "summon"):
        parts = line.split("Coords:[")

        afterpart = parts[-1].split("]")
        coords = [float(x) for x in afterpart[0].split(",")]

        edge = is_edge(coords)
        normal = "[" + ",".join([f"{x:.1f}" for x in point_normal(coords)]) + "]" if not edge else "[0.0,0.0,0.0]"

        coords = ",".join([f"{x * 2:.1f}" for x in coords])

        lines_out.append(" ".join(parts[:-1]) + "Coords:[" + coords + "]" + "]".join(afterpart[1:]))

        #print(coords, normal)
        
    else:
        lines_out.append(line)

open("spawnbigcube.mcfunction", "w").write("\n".join(lines_out))
