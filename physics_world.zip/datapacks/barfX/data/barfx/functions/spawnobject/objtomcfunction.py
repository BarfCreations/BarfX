import sys

def sign(x):
	return -1 if x < 0 else 1

if __name__ == "__main__":
	sqrSums = [0, 0, 0]
	if len(sys.argv) == 2 or True:
		with open(sys.argv[1]) as file:
			for line in file:
				elements = line.split()
				
				if(elements[0] == "v"):   
					coords = [float(x) for x in elements[1:4]]
					normal = [0, 0, 0]
					edgeCount = 0
					dimension = -1
					for (d, c) in enumerate(coords):
						if abs(c) > 0.4:
							edgeCount += 1
							dimension = d
							
					
					#print(f"<{coords[0]},{coords[1]},{coords[2]}>")
					sqrSums[0] += coords[1] ** 2 + coords[2] ** 2
					sqrSums[1] += coords[0] ** 2 + coords[2] ** 2
					sqrSums[2] += coords[0] ** 2 + coords[1] ** 2

					print(f"summon minecraft:marker ~{coords[0]} ~{coords[1]} ~{coords[2]} {{Tags:[Object,point,NewObject],data:{{Coords:[{coords[0]},{coords[1]},{coords[2]}],COR:0.7,COF:0.2}}}}")	
			print("\nfunction barfx:spawnobject/spawnobject")


			print("""scoreboard players set @e[tag=NewCOM] MomentX 10000
scoreboard players set @e[tag=NewCOM] MomentY 10000
scoreboard players set @e[tag=NewCOM] MomentZ 10000

scoreboard players set @e[tag=NewCOM] Mass 10000
""")

			print("\n#execute as @e[tag=NewCOM] run function barfx:rotation/randomrevolution")
			print("#execute as @e[tag=NewCOM] run function barfx:rotation/randomvelocity")

		#normal python things
	else:
		print(f"Usage: python3 objtomcfunction [filename]")
