header ="""
#CALCULATE JACOBIAN MATRIX FOR {n} POINTS:
#INPUTS:
"""[1:]

header_parameterized ="""
# PT {n}:
# JacobiCalcs.Collision{n}OffsetX
# JacobiCalcs.Collision{n}OffsetY
# JacobiCalcs.Collision{n}OffsetZ
# JacobiCalcs.Collision{n}NormalX
# JacobiCalcs.Collision{n}NormalY
# JacobiCalcs.Collision{n}NormalZ
"""[1:]

angular_and_linear ="""
#CALCULATE ANGULAR ACCELERATION FROM IMPULSE AT COLLISION {n}
#CROSS(P{n} offset, P{n} NORMAL) / moment
scoreboard players operation p2i3 JacobiCalcs = Collision{n}OffsetY JacobiCalcs
scoreboard players operation p2i3 JacobiCalcs *= Collision{n}NormalZ JacobiCalcs
scoreboard players operation p3i2 JacobiCalcs = Collision{n}OffsetZ JacobiCalcs
scoreboard players operation p3i2 JacobiCalcs *= Collision{n}NormalY JacobiCalcs
scoreboard players operation p1i3 JacobiCalcs = Collision{n}OffsetX JacobiCalcs
scoreboard players operation p1i3 JacobiCalcs *= Collision{n}NormalZ JacobiCalcs
scoreboard players operation p3i1 JacobiCalcs = Collision{n}OffsetZ JacobiCalcs
scoreboard players operation p3i1 JacobiCalcs *= Collision{n}NormalX JacobiCalcs
scoreboard players operation p1i2 JacobiCalcs = Collision{n}OffsetX JacobiCalcs
scoreboard players operation p1i2 JacobiCalcs *= Collision{n}NormalY JacobiCalcs
scoreboard players operation p2i1 JacobiCalcs = Collision{n}OffsetY JacobiCalcs
scoreboard players operation p2i1 JacobiCalcs *= Collision{n}NormalX JacobiCalcs

scoreboard players operation AngularAccelerationCollision{n}X JacobiCalcs = p3i2 JacobiCalcs
scoreboard players operation AngularAccelerationCollision{n}X JacobiCalcs -= p2i3 JacobiCalcs
scoreboard players operation AngularAccelerationCollision{n}X JacobiCalcs /= Moment RestitutionCalcs
scoreboard players operation AngularAccelerationCollision{n}Y JacobiCalcs = p1i3 JacobiCalcs
scoreboard players operation AngularAccelerationCollision{n}Y JacobiCalcs -= p3i1 JacobiCalcs
scoreboard players operation AngularAccelerationCollision{n}Y JacobiCalcs /= Moment RestitutionCalcs
scoreboard players operation AngularAccelerationCollision{n}Z JacobiCalcs = p2i1 JacobiCalcs
scoreboard players operation AngularAccelerationCollision{n}Z JacobiCalcs -= p1i2 JacobiCalcs
scoreboard players operation AngularAccelerationCollision{n}Z JacobiCalcs /= Moment RestitutionCalcs

#CALCULATE LINEAR ACCELERATION FROM IMPULSE AT COLLISION {n} 
scoreboard players operation LinearAccelerationCollision{n}X JacobiCalcs = Collision{n}NormalX JacobiCalcs
scoreboard players operation LinearAccelerationCollision{n}Y JacobiCalcs = Collision{n}NormalY JacobiCalcs
scoreboard players operation LinearAccelerationCollision{n}Z JacobiCalcs = Collision{n}NormalY JacobiCalcs
scoreboard players operation LinearAccelerationCollision{n}X JacobiCalcs *= 10000 const
scoreboard players operation LinearAccelerationCollision{n}Y JacobiCalcs *= 10000 const
scoreboard players operation LinearAccelerationCollision{n}Z JacobiCalcs *= 10000 const
scoreboard players operation LinearAccelerationCollision{n}X JacobiCalcs /= @s Mass
scoreboard players operation LinearAccelerationCollision{n}Y JacobiCalcs /= @s Mass
scoreboard players operation LinearAccelerationCollision{n}Z JacobiCalcs /= @s Mass


"""[1:]

matrix_self_component = """
#CALCULATE VELOCITY ON PT {n} FROM IMPULSE OF PT {n} (dv{n}/dI{n})
#CROSS(Angular{n}, Offset{n})
scoreboard players operation p2i3 JacobiCalcs = AngularAccelerationCollision{n}Y JacobiCalcs
scoreboard players operation p2i3 JacobiCalcs *= Collision{n}OffsetZ JacobiCalcs
scoreboard players operation p3i2 JacobiCalcs = AngularAccelerationCollision{n}Z JacobiCalcs
scoreboard players operation p3i2 JacobiCalcs *= Collision{n}OffsetY JacobiCalcs
scoreboard players operation p1i3 JacobiCalcs = AngularAccelerationCollision{n}X JacobiCalcs
scoreboard players operation p1i3 JacobiCalcs *= Collision{n}OffsetZ JacobiCalcs
scoreboard players operation p3i1 JacobiCalcs = AngularAccelerationCollision{n}Z JacobiCalcs
scoreboard players operation p3i1 JacobiCalcs *= Collision{n}OffsetX JacobiCalcs
scoreboard players operation p1i2 JacobiCalcs = AngularAccelerationCollision{n}X JacobiCalcs
scoreboard players operation p1i2 JacobiCalcs *= Collision{n}OffsetY JacobiCalcs
scoreboard players operation p2i1 JacobiCalcs = AngularAccelerationCollision{n}Y JacobiCalcs
scoreboard players operation p2i1 JacobiCalcs *= Collision{n}OffsetX JacobiCalcs

scoreboard players operation AngularAccelerationX JacobiCalcs = p3i2 JacobiCalcs
scoreboard players operation AngularAccelerationX JacobiCalcs -= p2i3 JacobiCalcs
scoreboard players operation AngularAccelerationX JacobiCalcs /= 10000 const
scoreboard players operation AngularAccelerationY JacobiCalcs = p1i3 JacobiCalcs
scoreboard players operation AngularAccelerationY JacobiCalcs -= p3i1 JacobiCalcs
scoreboard players operation AngularAccelerationY JacobiCalcs /= 10000 const
scoreboard players operation AngularAccelerationZ JacobiCalcs = p2i1 JacobiCalcs
scoreboard players operation AngularAccelerationZ JacobiCalcs -= p1i2 JacobiCalcs
scoreboard players operation AngularAccelerationZ JacobiCalcs /= 10000 const

scoreboard players operation AngularAccelerationX JacobiCalcs *= Collision{n}NormalX JacobiCalcs
scoreboard players operation AngularAccelerationY JacobiCalcs *= Collision{n}NormalY JacobiCalcs
scoreboard players operation AngularAccelerationZ JacobiCalcs *= Collision{n}NormalZ JacobiCalcs
scoreboard players operation AngularAccelerationX JacobiCalcs /= 10000 const
scoreboard players operation AngularAccelerationY JacobiCalcs /= 10000 const
scoreboard players operation AngularAccelerationZ JacobiCalcs /= 10000 const

scoreboard players set dv{n}dI{n} JacobiCalcs 100000000
scoreboard players operation dv{n}dI{n} JacobiCalcs /= @s Mass
scoreboard players operation dv{n}dI{n} JacobiCalcs += AngularAccelerationX JacobiCalcs
scoreboard players operation dv{n}dI{n} JacobiCalcs += AngularAccelerationY JacobiCalcs
scoreboard players operation dv{n}dI{n} JacobiCalcs += AngularAccelerationZ JacobiCalcs

"""[1:]

matrix_a_b = """
#CALCULATE VELOCITY ON PT {a} FROM IMPULSE OF PT {b} (dv{a}/dI{b})
#CROSS(Angular{a}, Offset{b})
scoreboard players operation p2i3 JacobiCalcs = AngularAccelerationCollision{a}Y JacobiCalcs
scoreboard players operation p2i3 JacobiCalcs *= Collision{b}OffsetZ JacobiCalcs
scoreboard players operation p3i2 JacobiCalcs = AngularAccelerationCollision{a}Z JacobiCalcs
scoreboard players operation p3i2 JacobiCalcs *= Collision{b}OffsetY JacobiCalcs
scoreboard players operation p1i3 JacobiCalcs = AngularAccelerationCollision{a}X JacobiCalcs
scoreboard players operation p1i3 JacobiCalcs *= Collision{b}OffsetZ JacobiCalcs
scoreboard players operation p3i1 JacobiCalcs = AngularAccelerationCollision{a}Z JacobiCalcs
scoreboard players operation p3i1 JacobiCalcs *= Collision{b}OffsetX JacobiCalcs
scoreboard players operation p1i2 JacobiCalcs = AngularAccelerationCollision{a}X JacobiCalcs
scoreboard players operation p1i2 JacobiCalcs *= Collision{b}OffsetY JacobiCalcs
scoreboard players operation p2i1 JacobiCalcs = AngularAccelerationCollision{a}Y JacobiCalcs
scoreboard players operation p2i1 JacobiCalcs *= Collision{b}OffsetX JacobiCalcs

scoreboard players operation AngularAccelerationX JacobiCalcs = p3i2 JacobiCalcs
scoreboard players operation AngularAccelerationX JacobiCalcs -= p2i3 JacobiCalcs
scoreboard players operation AngularAccelerationX JacobiCalcs /= 10000 const
scoreboard players operation AngularAccelerationY JacobiCalcs = p1i3 JacobiCalcs
scoreboard players operation AngularAccelerationY JacobiCalcs -= p3i1 JacobiCalcs
scoreboard players operation AngularAccelerationY JacobiCalcs /= 10000 const
scoreboard players operation AngularAccelerationZ JacobiCalcs = p2i1 JacobiCalcs
scoreboard players operation AngularAccelerationZ JacobiCalcs -= p1i2 JacobiCalcs
scoreboard players operation AngularAccelerationZ JacobiCalcs /= 10000 const

scoreboard players operation AngularAccelerationX JacobiCalcs *= Collision{b}NormalX JacobiCalcs
scoreboard players operation AngularAccelerationY JacobiCalcs *= Collision{b}NormalY JacobiCalcs
scoreboard players operation AngularAccelerationZ JacobiCalcs *= Collision{b}NormalZ JacobiCalcs

scoreboard players operation LinearAccelerationX JacobiCalcs = LinearAccelerationCollision{a}X JacobiCalcs
scoreboard players operation LinearAccelerationY JacobiCalcs = LinearAccelerationCollision{a}Y JacobiCalcs
scoreboard players operation LinearAccelerationZ JacobiCalcs = LinearAccelerationCollision{a}Z JacobiCalcs
scoreboard players operation LinearAccelerationX JacobiCalcs *= Collision{b}NormalX JacobiCalcs
scoreboard players operation LinearAccelerationY JacobiCalcs *= Collision{b}NormalY JacobiCalcs
scoreboard players operation LinearAccelerationZ JacobiCalcs *= Collision{b}NormalZ JacobiCalcs

scoreboard players operation dv{b}dI{a} JacobiCalcs = AngularAccelerationX JacobiCalcs
scoreboard players operation dv{b}dI{a} JacobiCalcs += AngularAccelerationY JacobiCalcs
scoreboard players operation dv{b}dI{a} JacobiCalcs += AngularAccelerationZ JacobiCalcs
scoreboard players operation dv{b}dI{a} JacobiCalcs += LinearAccelerationX JacobiCalcs
scoreboard players operation dv{b}dI{a} JacobiCalcs += LinearAccelerationY JacobiCalcs
scoreboard players operation dv{b}dI{a} JacobiCalcs += LinearAccelerationZ JacobiCalcs
scoreboard players operation dv{b}dI{a} JacobiCalcs /= 10000 const

"""[1:]

def do_generation(n, s):
    with open(f"jacobian_calculate_{s}_by_{s}_matrix.mcfunction", "w") as f:

        f.write(header.replace("{n}", f"{n}") + "\n")

        for i in range(n):
            f.write(header_parameterized.replace("{n}", f"{i+1}") + "\n")

        for i in range(n):
            f.write(angular_and_linear.replace("{n}", f"{i+1}") + "\n")

        for i in range(n):
            for j in range(n):
                if i == j:
                    f.write(matrix_self_component.replace("{n}", f"{i+1}") + "\n")
                else:
                    f.write(matrix_a_b.replace("{a}", f"{i+1}").replace("{b}", f"{j+1}") + "\n")


inputs = ((2, "two"), (3, "three"), (4, "four"), (5, "five"), (6, "six"), (7, "seven"), (8, "eight"), (9, "nine") )

for i in inputs:
    do_generation(*i)