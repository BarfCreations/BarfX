data_loading = """
execute store result score Collision{n}OffsetX JacobiCalcs run data get storage barfx:temp CollidedPts[{n-1}][0] 1
execute store result score Collision{n}OffsetY JacobiCalcs run data get storage barfx:temp CollidedPts[{n-1}][1] 1
execute store result score Collision{n}OffsetZ JacobiCalcs run data get storage barfx:temp CollidedPts[{n-1}][2] 1
execute store result score Collision{n}NormalX JacobiCalcs run data get storage barfx:temp CollidedPts[{n-1}][3] 1
execute store result score Collision{n}NormalY JacobiCalcs run data get storage barfx:temp CollidedPts[{n-1}][4] 1
execute store result score Collision{n}NormalZ JacobiCalcs run data get storage barfx:temp CollidedPts[{n-1}][5] 1
execute store result score Collision{n}PenetrationDepth JacobiCalcs run data get storage barfx:temp CollidedPts[{n-1}][6] 1
execute store result score Collision{n}PenetrationVelocity JacobiCalcs run data get storage barfx:temp CollidedPts[{n-1}][7] 1
"""[1:]

apply_impulses = """
scoreboard players operation ImpulseComponentX RestitutionCalcs = Collision{n}NormalX JacobiCalcs
scoreboard players operation ImpulseComponentY RestitutionCalcs = Collision{n}NormalY JacobiCalcs
scoreboard players operation ImpulseComponentZ RestitutionCalcs = Collision{n}NormalZ JacobiCalcs

scoreboard players operation ImpulseComponentX RestitutionCalcs *= Offset{n}_1 JacobiCalcs
scoreboard players operation ImpulseComponentY RestitutionCalcs *= Offset{n}_1 JacobiCalcs
scoreboard players operation ImpulseComponentZ RestitutionCalcs *= Offset{n}_1 JacobiCalcs

scoreboard players operation ImpulseComponentX RestitutionCalcs /= 10000 const
scoreboard players operation ImpulseComponentY RestitutionCalcs /= 10000 const
scoreboard players operation ImpulseComponentZ RestitutionCalcs /= 10000 const

scoreboard players operation CollisionOffsetX CollisionCalcs = Collision{n}OffsetX JacobiCalcs
scoreboard players operation CollisionOffsetY CollisionCalcs = Collision{n}OffsetY JacobiCalcs
scoreboard players operation CollisionOffsetZ CollisionCalcs = Collision{n}OffsetZ JacobiCalcs
function barfx:collision/applypsuedoimpulse

scoreboard players operation ImpulseComponentX RestitutionCalcs = Collision{n}NormalX JacobiCalcs
scoreboard players operation ImpulseComponentY RestitutionCalcs = Collision{n}NormalY JacobiCalcs
scoreboard players operation ImpulseComponentZ RestitutionCalcs = Collision{n}NormalZ JacobiCalcs

scoreboard players operation ImpulseComponentX RestitutionCalcs *= Impulse{n}_1 JacobiCalcs
scoreboard players operation ImpulseComponentY RestitutionCalcs *= Impulse{n}_1 JacobiCalcs
scoreboard players operation ImpulseComponentZ RestitutionCalcs *= Impulse{n}_1 JacobiCalcs

scoreboard players operation ImpulseComponentX RestitutionCalcs /= 10000 const
scoreboard players operation ImpulseComponentY RestitutionCalcs /= 10000 const
scoreboard players operation ImpulseComponentZ RestitutionCalcs /= 10000 const
function barfx:collision/applyimpulse

"""[1:]


def do_generation(n, s):
    with open(f"jacobi_{s}.mcfunction", "w") as f:
        for i in range(n):
            f.write(data_loading.replace("{n}", f"{i+1}").replace("{n-1}", f"{i}") + "\n")

        for i in range(n):
            f.write(angular_and_linear.replace("{n}", f"{i+1}") + "\n")

        for i in range(n):
            for j in range(n):
                if i == j:
                    f.write(matrix_self_component.replace("{n}", f"{i+1}") + "\n")
                else:
                    f.write(matrix_a_b.replace("{a}", f"{i+1}").replace("{b}", f"{j+1}") + "\n")



        for i in range(n):
            f.write("scoreboard players operation offset{n} JacobiCalcs = Collision{n}PenetrationDepth JacobiCalcs".replace("{n}",f"{i+1}") + "\n")
        f.write("\n")
        for i in range(n):
            f.write("scoreboard players operation impulse{n} JacobiCalcs = Collision{n}PenetrationVelocity JacobiCalcs".replace("{n}",f"{i+1}") + "\n")
        f.write("\n")
        f.write("function barfx:collision/resolve/solve_{number_string}\n".replace("{number_string}",s) + "\n")


        for i in range(n):
            f.write(apply_impulses.replace("{n}",f"{i+1}") + "\n")


inputs = ((3, "three"), (4, "four"), (5, "five"), (6, "six"), (7, "seven"), (8, "eight"), (9, "nine") )

for i in inputs:
    do_generation(*i)